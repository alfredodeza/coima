from logging import getLogger

## Set logger objects for all modules
middleware  = getLogger('raw.middleware')

